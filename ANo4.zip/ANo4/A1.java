package ANo4;
import java.util.ArrayList;


class A1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList<IQuestion> questions = new ArrayList<IQuestion>();
		questions.add(new TrueFaseQuestion(true, "Are you Okay"));
		questions.add(new ShortAnswerQuestion("How old are you?","90",10));
		
		for(IQuestion q:questions) {
			System.out.println("Q: "+ q.GetQuestion()+"("+q.GetScore()+")");
			System.out.println("A: "+ q.GetFormattedAnswer());
			System.out.println("-------------------------");
		}
		
	}
}
	

	
	

