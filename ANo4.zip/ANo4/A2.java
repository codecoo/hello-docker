package ANo4;

class A2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		TriviaGame theGame = new TriviaGame();
		theGame.AddQuestion(new TrueFaseQuestion(true, "Are you Okay"));
		theGame.AddQuestion(new ShortAnswerQuestion("How old are you?","90",10));
		theGame.Play();
	}
}
