package ANo4;

class A3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//enable timer
		TriviaGame theGame = new TriviaGame(true);
		theGame.AddQuestion(new TrueFaseQuestion(true, "Are you Okay"));
		theGame.AddQuestion(new ShortAnswerQuestion("How old are you?","90",10));
		theGame.Play();
	}
}
