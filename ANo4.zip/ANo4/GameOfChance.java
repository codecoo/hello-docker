package ANo4;

public class GameOfChance {
    private final int SIZE=5;
	public GameOfChance() {
		
	}
	public void PrintBoard() {
		
	}
	public void Play() {
		
	}
 
}
