package ANo4;

public class MoneyGrid extends Grid {

	public MoneyGrid(int amount) {
		super(amount);
		// TODO Auto-generated constructor stub
		
	}

}
