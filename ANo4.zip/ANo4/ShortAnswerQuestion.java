package ANo4;

public class ShortAnswerQuestion implements IQuestion {
	private String question;
	private String answer;
	private int score=0;
	public ShortAnswerQuestion(String question,String answer,int score){
		 this.question=question;
	     this.answer=answer;
		 this.score=score;
	}
	@Override
	public String GetQuestion(){
		return this.question;
	}
	@Override
	public Boolean CheckAnswer(String answer){
	return (this.answer.equals(answer));
	}
	@Override
	public String GetFormattedAnswer(){
		return this.answer.toString();
	}
	@Override
	public int GetScore(){
		return this.score;
	}
}

