package ANo4;

public class TrueFaseQuestion implements IQuestion {
	private String question;
	private Boolean answer;
	private int score=1;
	public TrueFaseQuestion(Boolean answer,String question){
		 this.question=question;
	     this.answer=answer;
	}
	@Override
	public String GetQuestion() {
		return this.question+"(true/false?)";
	}
	@Override
	public Boolean CheckAnswer(String answer) {
		return this.answer.equals(Boolean.valueOf(answer));
	}
	@Override
	public String GetFormattedAnswer() {
		return this.answer.toString();
	}
	@Override
	public int GetScore(){
		return this.score;
	}
}