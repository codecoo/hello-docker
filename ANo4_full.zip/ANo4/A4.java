package ANo4;

class A4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		GameOfChance theGame = new GameOfChance();
		theGame.Play();
	
	}
}
