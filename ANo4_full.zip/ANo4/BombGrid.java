package ANo4;

public class BombGrid extends Grid {

	public BombGrid(int amount) {
		super(amount);
		// TODO Auto-generated constructor stub
	}
	@Override
	public void Effect(Player p) {
		p.SetHp(p.GetHp()-1);
	}

}
