package ANo4;

import java.util.Random;
import java.util.Scanner;

public class GameOfChance {
    private final int SIZE=5;
    private Grid[][] grids = new Grid[SIZE][SIZE];
    private final int MAX_PICK=10;
	public GameOfChance() {
		int k,j=0;
		for(j=0;j<SIZE;j++){
            for(k=0;k<SIZE;k++){
            	Random r = new Random();
            	Random rm = new Random();
            	if(r.nextBoolean())
            		grids[j][k]=new BombGrid(1);
            	else
            		grids[j][k] = new MoneyGrid(rm.nextInt(20));
            }
         }
		
	}
	public void PrintBoard() {
	  	
		int k,j=0;
		for(j=0;j<SIZE;j++){
            for(k=0;k<SIZE;k++){
            	 Grid g = grids[j][k];
            	 g.Print();
            }
            System.out.println();
         }
	  	  
	}
	public void Play() {
		
		Scanner reader = new Scanner(System.in);
		System.out.println("Game Get Start");
		Player p = new Player();
		for(int i=0;i<MAX_PICK;i++) {
			
			this.PrintBoard();
			System.out.println("------- Pick "+ (i+1) +" --------");
			System.out.println("Choose the grid to open (x,y)");
			String pick_xy = reader.next();
			if(pick_xy.length()>0) {
			   String[] xy = pick_xy.split(",");
			   if(xy.length==2) {
				   int x =Integer.parseInt(xy[0]);
				   int y =Integer.parseInt(xy[1]);
				   Grid g = this.grids[x][y];
				   String status = (g instanceof BombGrid)? "BOMB status":"MONEY status";
				   if(!g.IsOpen()) {
					   g.SetOpen(true);
					   g.Effect(p);
					   System.out.println(status+" HP: "+p.GetHp()+" Total Money:"+ p.GetMoney());
				   }else
					   System.out.println("Error : this grid already opened");
				   
				   this.grids[x][y]=g;
			   }
			}
			
			//Game Over
			if(p.GetHp()==0){
				System.out.println("Game Over");
				break;
			}
			
		}
		reader.close();
		System.out.println("End of The Game");
	}
 
}
