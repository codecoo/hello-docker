package ANo4;

public class Grid {
   private Boolean isOpen = false;
   private int amount=0;
   public Grid(int amount) {
	    this.amount=amount;
   }
   public Boolean IsOpen() {
	   return this.isOpen;
   }
   public int GetAmount() {
	   return this.amount;
   }
   public void Print() {
	   if(this.isOpen)
      	 System.out.print(this.amount+" ");
       else
      	 System.out.print("X"+" ");
   }
   public void Effect(Player p) {
	   
   }
   public void SetOpen(Boolean isOpen) {
	    this.isOpen=isOpen;
   }
   
}
