package ANo4;

public 	interface IQuestion{
	public String GetQuestion();
	public Boolean CheckAnswer(String answer);
	public String GetFormattedAnswer();
	public int GetScore();
}
