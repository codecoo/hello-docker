package ANo4;

public class MoneyGrid extends Grid {

	private int amount=0;
	public MoneyGrid(int amount) {
		super(amount);
		// TODO Auto-generated constructor stub
		this.amount=amount;
	}
	@Override
	public void Effect(Player p) {
		p.SetMoney(p.GetMoney()+this.amount);
	}

}
