package ANo4;

public class Player {
 private int money=0;
 private int hp;
 
 public Player() {
	 this.money=0;
	 this.hp=3;
 }
 public int GetMoney() {
	 return this.money;
 }
 public void SetMoney(int money) {
	 this.money=money;
 }
 public int GetHp() {
	 return this.hp;
 }
 public void SetHp(int hp) {
	 this.hp=hp;
 }
 
}
