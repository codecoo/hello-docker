package ANo4;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Timer;
import java.util.TimerTask;


public class TriviaGame {
   private int totalScore=0;
   private Boolean isTimer = false;
   private ArrayList<IQuestion> questions;
   private Timer timer;
   private int current_seconds = 0;
   private int countdown_seconds = 3;
   private int current_question = 0;
   private int max_question = 0;
   private final int MAX_SECONDS = 10;
   
   public TriviaGame() {
	   this.questions= new ArrayList<IQuestion>();
   }
   public TriviaGame(Boolean isTimer) {
       this.isTimer= isTimer;
	   this.questions= new ArrayList<IQuestion>();
   }
   public void AddQuestion(IQuestion q) {
	   this.questions.add(q);
   }
   public void Play() {
	   
	   Scanner reader = new Scanner(System.in);
	   if(isTimer) {
		   timer= new Timer();
		   TimerTask task = new TimerTask() {
		        @Override
		        public void run() { 
		            if (current_seconds <= MAX_SECONDS) {
		            	if(current_seconds>6) {
		            		System.out.println("Countdown:" + countdown_seconds);
		                    countdown_seconds--;
		            	}
		                current_seconds++;
		            } else {
		                // stop the timer
		            	System.out.println("Time Out-->"+" Total Score :"+ totalScore);
		                cancel();
		            }
		        }
		    };
		    timer.schedule(task, 0,1000); // 1 second
	   }
	   
	   max_question= this.questions.size();
	   for(IQuestion q:this.questions) {
		   
			System.out.println("Q: "+ q.GetQuestion()+"("+q.GetScore()+")");
			System.out.println("A: ");
			String answer = reader.next();
			String result_msg="Wrong!";
			current_question++;
			if(q.CheckAnswer(answer)) {
				result_msg="Correct!";
				totalScore+=q.GetScore();
			}
			System.out.println("Result: "+result_msg+" Total Score :"+ totalScore);
			System.out.println("-------------------------");
			//stop timer if finish all question
			if(max_question==current_question)
				timer.cancel();
		}
	   reader.close();
	   
   }
   
}
